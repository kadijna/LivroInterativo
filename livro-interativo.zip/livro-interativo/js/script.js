var leftObj;
var topObj;
var valueObj;
var acertos = 0;
var quantosLi = 0;
var quantosI = 0;
var quantosAlt = 0;
var List = $('#bloco ul');


var imgs = [];

var sala = ['JA', 'COR', 'CA', 'COR', 'SO', 'VA', 'VA'];
var sala2 = ['CA', 'TE', 'SA', 'TA', 'JA', 'CA', 'SO'];
var imgs = ['icon-jaca', 'icon-corte', 'icon-casa', 'icon-corta', 'icon-soja', 'icon-vaca','icon-vaso'];
var imgAlt = ['Jaca', 'Corte', 'Casa', 'Corta', 'Soja', 'Vaca','Vaso'];

var index = 0;




function init() {

  acertos = 0;
  quantosLi = 0;
  quantosI = 0;
  quantosAlt = 0;

  $("#bloco ul li").each(function (index) {
    quantosLi = quantosLi + 1;
  });

  $('#img').each(function(index) {
   quantosI = quantosI + 1;
  });

  $('#img').each(function(index) {
   quantosAlt = quantosAlt + 1;
  });


  console.log("init");

  $('li.drop:nth-child(1)').attr("value", sala[index]);
  $('li.drop:nth-child(2)').attr("value", sala2[index]);
  $('#img').addClass(imgs[index]);
  $('#img').attr("alt", imgAlt[index]);
  $('#img').removeClass(imgs[index - 1]);
}

$(function () {
  $(".obj").draggable({
    start: function (event, ui) {
      var offset = $(this).offset();
      leftObj = offset.left;
      topObj = offset.top;
      valueObj = $(this).attr("value");
    },
    stop: function (event, ui) {
      $(this).css({
        'left': leftObj,
        'top': topObj,
        'position': 'absolute'
      });
    }
  });
  $(".drop").droppable({
    drop: function (event, ui) {

      valueObj2 = $(this).attr("value");

      $(this)
        .addClass("dropped")
      if (valueObj == valueObj2) {
        $(this).find("p")
          .html(valueObj);
        $(this).droppable('disable');
        acertos++;
        console.log(acertos);
        if (acertos == quantosLi) {

          $("#bloco-acerto").show();

          setTimeout(function () {
            $(".drop").find("p").text("");
          }, 1000);

          if(index < sala.length){
            index++;
            init();
            $(".drop").droppable('enable');
          }
        }
      }
    }
  });
  $(".obj").mouseover(function () {
    event.stopPropagation();
    if ($(this).find('span').length == 0) {
      $(this).append($("<span/>").css({ "background-color": "#fff", "padding": "5px", "border-radius": "5px" }).text($(this).attr("alt")).show());
    }
  });
  $(".obj").mouseout(function () {
    $("span").remove();
  });

  $("#img").mouseover(function () {
    event.stopPropagation();
    if ($(this).find('span').length == 0) {
      $(this).append($("<span/>").css({ "background-color": "#dedede", "top": "2.5em", "padding": "5px 8px","padding-bottom": "10px", "border-radius": "5px", "color": "#545454", "position": "absolute" }).text($(this).attr("alt")).show());
    }
  });
  $("#img").mouseout(function () {
    $("span").remove();
  });

  $( "#fechar" ).click(function() {
    $( "#bloco-acerto" ).hide();
  });

});



$(document).ready(function () {

  init();

});
